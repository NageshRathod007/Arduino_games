
class Pong
{
  private:
    int level;
  public:
    Ball ball;
    int nofBumpers;
    point bumpers[2];
    void update();
    void play();
    void gameOver();
    void levelUp();
    void updateBumpers(point bumper, Ball *ball);
};
