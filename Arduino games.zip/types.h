typedef struct point
{
  int x;
  int y;
};

enum games { gmMenu = 0, gmPong = 1, gmTedshow = 2, gmSpaceInvaders = 3, gmSnake = 4 };

enum steering { stLeft, stCentre, stRight };

enum tedShowState { tsLights, tsFalling };
