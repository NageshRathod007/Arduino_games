class Menu
{
  private:
    const int width = 32;
    const int height = 8;
    games selectedGame;
    long elpased;
    games currentGame = gmMenu;
    void updateMenu();
    void updatePong();
  public:
    void initialize();
    void update();
    bool between(int val, int min, int max);
    void startGame(int offset);
};
